
package javacrud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author 16127512022.2
 */
public class Crudjava {

    public static void main(String[] args) throws SQLException {
      
        Connection conexao= null;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
        conexao = DriverManager.getConnection("jdbc:mysql://localhost/aula_sql","root","");
        ResultSet rscliente = conexao.createStatement().executeQuery("SELECT * FROM clientes");
        while(rscliente.next()){
        System.out.println("Nome " +rscliente.getString("nome") );
        }
        }catch(ClassNotFoundException ex){
        
        System.out.println("conexao falhou.");
        
 
            
        }
        
    }
}
