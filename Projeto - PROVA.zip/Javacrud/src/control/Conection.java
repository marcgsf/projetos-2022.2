
package control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author 16127512022.2
 */
public class Conection {

    public static void main(String[] args) throws SQLException {
      
        Connection conexao= null;
        
        try{
        conexao = DriverManager.getConnection("jdbc:sqlite:src/control/jbooker.db");
        ResultSet rscliente = conexao.createStatement().executeQuery("SELECT * FROM book");
        while(rscliente.next()){
        System.out.println("titulo " +rscliente.getString("title") );
        }
        }catch(SQLException ex){
        
        System.out.println("conexao falhou." +ex);
        
 
            
        }
        
    }
}
