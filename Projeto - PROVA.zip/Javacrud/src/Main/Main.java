
package Main;

import com.sun.jdi.connect.spi.Connection;
import control.Conection;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) {
    
  
        
        
      Scanner pesquisar = new Scanner(System.in);
    System.out.print("Digite sua acao :");
    String req = pesquisar.nextLine(); 
    
    if("cadastrar".equals(req)){
    Scanner Title =new Scanner(System.in);
    System.out.print("Digite o titulo do livro : ");
String title = Title.nextLine();    
        
    Scanner Autor =new Scanner(System.in);
    System.out.print("Digite o nome do Autor do livro : ");
String autor = Autor.nextLine();

Scanner Isbn =new Scanner(System.in);
    System.out.print("Digite o Codigo de barra do livro : ");
String isbn = Isbn.nextLine();   


Scanner Pages =new Scanner(System.in);
    System.out.print("Digite o Número de páginas do livro :");
String pages = Pages.nextLine();


Scanner Price =new Scanner(System.in);
    System.out.print("Digite o Preco do livro :");
String price = Price.nextLine();

Scanner Confirma =new Scanner(System.in);
    System.out.print("Deseja salvar o cadastro : s/n?");
String confirma = Confirma.nextLine();

if("s".equals(confirma)){

Conection conexaoDB = new Conection();

Connection conn = conexaoDB.dbConnect();

String SQL = "INSERT INTO book (id ,title,author,isbn,pages,price) VALUES('NULL','"+title+"','"+autor+"','"+isbn+",'"+pages+",'"+price+"')";


PreparedStatement pstm = conn.prepareStatement(SQL);

ResulSet res = pstm.executeQuery();

}
else {return;}
    }
    
    
    
    if("pesquisar".equals(req)){
    
    Scanner Title =new Scanner(System.in);
    System.out.print("Digite o titulo do livro : ");
String title = Title.nextLine();  
    
    }
    
    
    }
//    Scanner cadastrar = new Scanner(System.in);
//    Scanner filtrar = new Scanner(System.in);
//    Scanner deletar = new Scanner(System.in);
    
   
}
